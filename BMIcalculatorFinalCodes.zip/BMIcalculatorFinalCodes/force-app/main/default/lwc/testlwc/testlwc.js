import { LightningElement } from 'lwc';

export default class Testlwc extends LightningElement {}